package com.scloud.homeactivity;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.dropbox.client2.DropboxAPI.Entry;
import com.dropbox.client2.exception.DropboxException;
import com.scloud.adapters.FilesListAdapter;
import com.scloud.core.DropBoxWrapper;

public class FilesListActivity extends Activity implements OnItemClickListener,
		OnItemLongClickListener,DialogInterface.OnClickListener{
	private final String TAG = "ListFilesActivity";
	ListView mFileListView;
	public FilesListAdapter mListAdapter;
	Entry currEntry;
	DropBoxWrapper mDropboxWrapper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_activity);
		if (mListAdapter == null) {
			this.mFileListView = (ListView) findViewById(R.id.list_fileslistview);
			this.mListAdapter = new FilesListAdapter(this, R.layout.list_file);
			this.mDropboxWrapper = DropBoxWrapper
					.getInstance(FilesListActivity.this);
			mFileListView.setOnItemClickListener(this);
			mFileListView.setOnItemLongClickListener(this);
			mFileListView.setAdapter(mListAdapter);
			new FileFetcher().execute("/SCloud");
		}
	}

	public class FileFetcher extends AsyncTask<String, Void, Object> {

		@Override
		protected void onPreExecute() {

			super.onPreExecute();
		}

		@Override
		protected Object doInBackground(String... params) {
			try {
				return mDropboxWrapper.listFiles(params[0]);
			} catch (DropboxException e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(Object res) {
			super.onPostExecute(res);
			Entry result = (Entry) res;
			ArrayList<Entry> uploadedFiles = (ArrayList<Entry>) result.contents;
			for (Entry fileList : uploadedFiles) {
				mListAdapter.addAll(fileList.fileName());
				mListAdapter.notifyDataSetChanged();

			}
		}

	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		Log.i(TAG, "Clicked Id:" + id);
		this.mListAdapter.processClick(id);
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> parent, View view,
			int position, final long id) {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(FilesListActivity.this);
		alertDialog.setTitle("Download File...");
		alertDialog.setPositiveButton("Download",new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				mListAdapter.initiateDownload(id);
			}
		});
		alertDialog.create();
		alertDialog.show();
		// this.mListAdapter.initiateDownload(id);
		return true;

	}

	@Override
	public void onClick(DialogInterface dialog, int which) {
		// TODO Auto-generated method stub
		
	}
	
	

	

	

}
