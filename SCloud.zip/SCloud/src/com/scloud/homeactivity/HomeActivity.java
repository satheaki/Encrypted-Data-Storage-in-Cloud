package com.scloud.homeactivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.dropbox.client2.exception.DropboxException;
import com.orleonsoft.android.simplefilechooser.Constants;
import com.orleonsoft.android.simplefilechooser.ui.FileChooserActivity;
import com.scloud.core.DropBoxWrapper;
import com.scloud.dropboxconstants.DropBoxConstants;
import com.scloud.encyptionutils.Crypt;
import com.scloud.helper.PreferenceHelper;

public class HomeActivity extends Activity {
	private final String TAG = "HomeActivity";
	private DropBoxWrapper mDropboxWrapper;
	Button mUploadFileButton;
	ProgressDialog mProgressDialog;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		mUploadFileButton = (Button) findViewById(R.id.fileuploadbtn);
		mUploadFileButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				mDropboxWrapper = DropBoxWrapper.getInstance(HomeActivity.this);
				startFilePicker();
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		if (PreferenceHelper.getStringData(DropBoxConstants.ACCESS_TOKEN) == null) {
			Log.d(TAG, "what is null=" + mDropboxWrapper);
			mDropboxWrapper.finishAuthentication();
		}
		new Thread() {
			public void run() {
				startFilePicker();
			}
		}.start();

	}

	private void startFilePicker() {
		Intent filePickerIntent = new Intent(HomeActivity.this,
				FileChooserActivity.class);
		startActivityForResult(filePickerIntent, DropBoxConstants.FILE_CHOOSER);

	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if ((requestCode == DropBoxConstants.FILE_CHOOSER)
				&& (resultCode == RESULT_OK)) {
			final String fileSelected = data
					.getStringExtra(Constants.KEY_FILE_SELECTED);
			
			final String[] pickedFile=fileSelected.split("/"); 
			new Thread() {
				@Override
				public void run() {
					uploadFileToDropbox(fileSelected);
				//	new DropBoxFileFetcher(pickedFile);
				}
			}.start();

			Log.i(TAG, fileSelected);

		}
	}

	public void switchtoList() {
		Intent intent = new Intent(HomeActivity.this, FilesListActivity.class);
		startActivity(intent);
	}

	private Handler handler = new Handler(new Callback() {

		@Override
		public boolean handleMessage(Message msg) {
			switch (msg.what) {
			case 0:
				Toast.makeText(getApplicationContext(),
						"File Uploaded Successfully", Toast.LENGTH_LONG).show();
				return true;
			default:
				return false;
			}
		}
	});

	
		
	private void uploadFileToDropbox(String fileSelectedPath) {
		try {
			File inputFile = new File(fileSelectedPath);
			

			String[] splitter = fileSelectedPath.split("/");
			String fileName = splitter[3];
			
			File outputFile=new File(Environment.getExternalStorageDirectory(),"encrypted"+fileName);
			if(!outputFile.exists())
				outputFile.createNewFile();

			Crypt.encrypt(DropBoxConstants.CIPHER_KEY, inputFile, outputFile);
			FileInputStream fileStream = new FileInputStream(outputFile);
			com.dropbox.client2.DropboxAPI.Entry response = mDropboxWrapper.mDropBoxAPI
					.putFile("/SCloud/" + fileName, fileStream,
							outputFile.length(), null, null);

			this.handler.sendEmptyMessage(0);
			
			outputFile.delete();
			new Thread() {
				public void run() {
					switchtoList();
				}
			}.start();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (DropboxException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
	}

}
