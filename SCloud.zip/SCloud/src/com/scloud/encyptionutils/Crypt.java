package com.scloud.encyptionutils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import android.media.MediaCodec.CryptoException;
import android.util.Log;

/**
 * A class which encrypts and decrypts file
 * 
 * @author Akshay
 *
 */
public class Crypt {
	private static final String ALGORITHM = "AES";
	private static final String TRANSFORMATION = "AES";

	public static void encrypt(String key, File inputFile, File outputFile)
			throws CryptoException {
		doCrypto(Cipher.ENCRYPT_MODE, key, inputFile, outputFile);
	}

	public static void decrypt(String key, File inputFile, File outputFile)
			throws CryptoException {
		doCrypto(Cipher.DECRYPT_MODE, key, inputFile, outputFile);
	}

	/**
	 * Method for encrypting and decrypting file using AES256 bit
	 * encryption,decryption algorithm
	 * 
	 * @param cipherMode
	 *            :encrty or decrypt
	 * @param key
	 *            :cipher key requied for encrption and decryption
	 * @param inputFile
	 *            :Input file for encrption
	 * @param outputFile
	 *            :encrypted output file
	 */
	private static void doCrypto(int cipherMode, String key, File inputFile,
			File outputFile) {
		try {
			SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(),
					ALGORITHM);
			Cipher cipher = Cipher.getInstance(TRANSFORMATION);
			cipher.init(cipherMode, secretKey);

			FileInputStream inputStream = new FileInputStream(inputFile);
			byte[] inputBytes = new byte[(int) inputFile.length()];
			
			Log.d("Cipher", "InputBytes:"+inputBytes);
			Log.d("Cipher", "InputStream:"+inputStream.read(inputBytes));
			inputStream.read(inputBytes);

			byte[] outputBytes = cipher.doFinal(inputBytes);
			
			Log.d("Cipher","OutputBytes:"+outputBytes);

			FileOutputStream outputStream = new FileOutputStream(outputFile);
			outputStream.write(outputBytes);
			inputStream.close();
			outputStream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
