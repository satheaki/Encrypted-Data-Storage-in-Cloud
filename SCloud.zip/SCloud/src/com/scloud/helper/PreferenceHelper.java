package com.scloud.helper;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

/**
 * @author akshay
 * 
 */
public class PreferenceHelper {
	private static PreferenceHelper sPreferenceHelper;
	private static Context sContext;
	private static SharedPreferences sSharedPreferences;
	private static SharedPreferences.Editor sEditor;

	/**
	 * This class is used as singleton so private constructor
	 * 
	 * @param context
	 */

	private PreferenceHelper(Context context) {
		if (context == null) {
			Log.d("asdfas", "dsfasdf");
		}
		PreferenceHelper.sContext = context;
		PreferenceHelper.sSharedPreferences = PreferenceHelper.sContext
				.getSharedPreferences("User_data", Context.MODE_PRIVATE);
		PreferenceHelper.sEditor = PreferenceHelper.sSharedPreferences.edit();
	}

	/**
	 * Returns the singleton object for this class
	 * 
	 * @param context
	 *            Context
	 * @return Instance of {@link PreferenceHelper}
	 */
	public static synchronized PreferenceHelper getInstance(Context context) {
		if (PreferenceHelper.sPreferenceHelper == null) {
			PreferenceHelper.sPreferenceHelper = new PreferenceHelper(context);

		}
		return PreferenceHelper.sPreferenceHelper;
	}

	/**
	 * Save string data to persistent storage
	 * 
	 * @param key
	 * @param value
	 */

	public static void saveData(String key, String value) {
		PreferenceHelper.sEditor.putString(key, value);
		PreferenceHelper.sEditor.commit();
	}

	
		
	/**
	 * Get stored string value
	 * 
	 * @param key
	 * @return
	 */
	public static String getStringData(String key) {
		Log.d("pfhelper","retrieved token="+PreferenceHelper.sSharedPreferences.getString(key, null));
		return PreferenceHelper.sSharedPreferences.getString(key, null);
	}

	}
