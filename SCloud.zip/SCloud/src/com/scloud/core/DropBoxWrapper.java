package com.scloud.core;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.os.Environment;
import android.preference.Preference;
import android.util.Log;

import com.dropbox.client2.DropboxAPI;
import com.dropbox.client2.DropboxAPI.DropboxFileInfo;
import com.dropbox.client2.DropboxAPI.Entry;
import com.dropbox.client2.android.AndroidAuthSession;
import com.dropbox.client2.exception.DropboxException;
import com.dropbox.client2.session.AppKeyPair;
import com.scloud.dropboxconstants.DropBoxConstants;
import com.scloud.encyptionutils.Crypt;
import com.scloud.helper.PreferenceHelper;

/**
 * @author Akshay
 *
 */
public class DropBoxWrapper {
	public final DropboxAPI<AndroidAuthSession> mDropBoxAPI;
	private final AppKeyPair mAppKeys;
	private final AndroidAuthSession mAuthSession;
	private static DropBoxWrapper sDropboxWrapper;

	public DropBoxWrapper(Activity returnActivity) {
		this.mAppKeys = new AppKeyPair(DropBoxConstants.APP_KEY,
				DropBoxConstants.APP_SECRET_KEY);
		PreferenceHelper mhelper = PreferenceHelper.getInstance(returnActivity);
		String accessToken = PreferenceHelper
				.getStringData(DropBoxConstants.ACCESS_TOKEN);
		Log.d("DropBoxConstructor", "accessToken=" + accessToken);
		// String accessToken=null;
		if (accessToken == null) {
			this.mAuthSession = new AndroidAuthSession(this.mAppKeys);
			this.mDropBoxAPI = new DropboxAPI<AndroidAuthSession>(
					this.mAuthSession);
			this.mDropBoxAPI.getSession().startOAuth2Authentication(
					returnActivity);
			// }
		} else {
			this.mAuthSession = new AndroidAuthSession(this.mAppKeys,
					accessToken);
			this.mDropBoxAPI = new DropboxAPI<AndroidAuthSession>(
					this.mAuthSession);
		}
	}

	public void finishAuthentication() {
		mDropBoxAPI.getSession().finishAuthentication();
		PreferenceHelper.saveData(DropBoxConstants.ACCESS_TOKEN,
				this.mDropBoxAPI.getSession().getOAuth2AccessToken());
	}

	public String getAccessToken() {
		return this.mDropBoxAPI.getSession().getOAuth2AccessToken();
	}

	public Entry listFiles(String path) throws DropboxException {
		Log.i("Dropbox", "Inside getfile function");
		Entry files = this.mDropBoxAPI.metadata(path, 0, null, true, null);
		Log.d("DropBoxWrapper", "entry fetched:" + files.contents.toString());
		Log.d("DropBoxWrapper", "File name:" + files.fileName());
		Log.d("DropBoxWrapper", "Path:" + files.path);

		return files;

	}

	public static synchronized DropBoxWrapper getInstance(
			Activity returnActivity) {
		Log.d("wrapper", "inside wrapper:" + DropBoxWrapper.sDropboxWrapper);
		if (DropBoxWrapper.sDropboxWrapper == null) {
			DropBoxWrapper.sDropboxWrapper = new DropBoxWrapper(returnActivity);
			Log.d("wrapper", "inside wrapper after constructor:"
					+ DropBoxWrapper.sDropboxWrapper);
		}
		return sDropboxWrapper;
	}

	public File downloadFile(String fileName, String pathName) {
		try {
			File inputFile = new File(
					Environment.getExternalStorageDirectory(), "/ScloudData/"
							+ fileName);
			File outputFile = new File(
					Environment.getExternalStorageDirectory(),
					"/SCloudDecryptedData/" + fileName);
			if (!outputFile.exists())
				outputFile.createNewFile();
			Crypt.decrypt(DropBoxConstants.CIPHER_KEY, inputFile, outputFile);
			return outputFile;
		} catch (IOException e) {
		}
		return null;

	}

	public File getFiles(String fileName, String pathName) {
		FileOutputStream outputStream = null;
		try {
			File file = new File(Environment.getExternalStorageDirectory()
					+ "/ScloudData/" + fileName);
			if (!file.exists()) {
				file.createNewFile();
			}
			outputStream = new FileOutputStream(file);
			DropboxFileInfo info = this.mDropBoxAPI.getFile(pathName, null,
					outputStream, null);
			Log.d("DropBoxWrapper", "File info:" + info);
			return file;
		} catch (IOException e) {
			e.printStackTrace();
		} catch (DropboxException e) {
			e.printStackTrace();
		} finally {
			if (outputStream != null)
				try {
					outputStream.close();
				} catch (IOException e) {
					// e.printStackTrace();
				}
		}
		return null;

	}
}
