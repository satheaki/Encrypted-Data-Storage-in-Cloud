package com.scloud.dropboxconstants;

/**
 * @author Akshay
 *
 */
public class DropBoxConstants {
	
	public final static String APP_KEY="7kqmuhndnwu2rau";
	public final static String APP_SECRET_KEY="qmo6g8w9e7rx8h6";
	public final static int FILE_CHOOSER=1;
	public final static String CIPHER_KEY="1234567890123456";
	public final static String ACCESS_TOKEN = "access_token";
	
	public DropBoxConstants() {

	}
	
}
