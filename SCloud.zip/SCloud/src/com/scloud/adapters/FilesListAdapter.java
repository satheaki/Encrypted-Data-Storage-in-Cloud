package com.scloud.adapters;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import android.app.ListFragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.sax.StartElementListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.dropbox.client2.DropboxAPI.Entry;
import com.orleonsoft.android.simplefilechooser.ui.FileChooserActivity;
import com.scloud.core.DropBoxWrapper;
import com.scloud.dropboxconstants.DropBoxConstants;
import com.scloud.encyptionutils.Crypt;
import com.scloud.homeactivity.FilesListActivity;
import com.scloud.homeactivity.HomeActivity;

/**
 * @author Akshay
 *
 */
public class FilesListAdapter extends ArrayAdapter<Object> {
	private LayoutInflater mLayoutInflater;
	ProgressDialog mProgressDialog;
	private Context mContext;
	Entry getFileEntry;

	public FilesListAdapter(Context context, int resource) {
		super(context, resource);
		mLayoutInflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mContext = context;
	}

	private class ViewHolder {
		TextView mFileName;
		ImageView mFileIcon;
		View view;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = this.mLayoutInflater.inflate(
					com.scloud.homeactivity.R.layout.list_file, null);
			holder = new ViewHolder();
			holder.mFileName = (TextView) convertView
					.findViewById(com.scloud.homeactivity.R.id.cell_file_name);
			holder.mFileIcon = (ImageView) convertView
					.findViewById(com.scloud.homeactivity.R.id.cell_file_icon);
			holder.view = (LinearLayout) convertView
					.findViewById(com.scloud.homeactivity.R.id.linear_layout1);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		holder.mFileIcon
				.setImageResource(com.scloud.homeactivity.R.drawable.file);
		holder.mFileName.setText(getItem(position).toString());

		if (position % 2 == 0)
			holder.view.setBackgroundColor(Color.parseColor("#EAEAEA"));
		else
			holder.view.setBackgroundColor(Color.parseColor("#F9F9F9"));

		return convertView;

	}

	public void processClick(long id) {
		Object object = super.getItem((int) id);
		String data[] = { object.toString(), "/SCloud/" + object.toString() };
		new FetchFile().execute(data);
	}

	public void initiateDownload(long id) {
		Object object = super.getItem((int) id);
		String data[] = { object.toString(), "/SCloud/" + object.toString() };
		new DownloadFile().execute(data);
	}

	private class DownloadFile extends AsyncTask<String, Void, File> {

		String mimeType;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mProgressDialog = new ProgressDialog(mContext);
			mProgressDialog.setTitle("Downloading...");
			mProgressDialog.setCancelable(true);
			mProgressDialog.setIndeterminate(true);
			mProgressDialog.show();
			// mProgressDialog.dismiss();

		}

		@Override
		protected File doInBackground(String... params) {
			DropBoxWrapper.getInstance(null).getFiles(params[0], params[1]);
			return DropBoxWrapper.getInstance(null).downloadFile(params[0],
					params[1]);
		}

		@Override
		protected void onPostExecute(File encryptedFile) {
			super.onPostExecute(encryptedFile);
			FilesListAdapter.this.openFile(encryptedFile, mimeType);
			mProgressDialog.dismiss();
		}

	}

	private class FetchFile extends AsyncTask<String, Void, File> {

		String mimeType;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			mProgressDialog = new ProgressDialog(mContext);
			mProgressDialog.setTitle("Loading...");
			mProgressDialog.setCancelable(true);
			mProgressDialog.setIndeterminate(true);
			mProgressDialog.show();

		}

		@Override
		protected File doInBackground(String... params) {

			return DropBoxWrapper.getInstance(null).getFiles(params[0],
					params[1]);

		}

		@Override
		protected void onPostExecute(File result) {
			super.onPostExecute(result);
			FilesListAdapter.this.openFile(result, mimeType);
			mProgressDialog.dismiss();
		}

	}

	public void openFile(File file, String mimeType) {
		Uri uri = Uri.fromFile(file);

		try {
			Intent intent = new Intent();
			intent.setAction(android.content.Intent.ACTION_VIEW);
			if (file.toString().contains(".txt"))
				mimeType = "text/plain";
			else if (file.toString().contains(".pdf"))
				mimeType = "application/pdf";
			else if (file.toString().contains(".doc")
					|| file.toString().contains(".docx"))
				mimeType = "application/msword";
			if (file.toString().contains(".jpeg")
					|| file.toString().contains(".jpg"))
				mimeType = "image/jpg";
			intent.setDataAndType(uri, mimeType);
			this.mContext.startActivity(intent);
		} catch (Exception e) {
			e.printStackTrace();
			Toast.makeText(getContext(), "File type not supported",
					Toast.LENGTH_LONG).show();
		}
	}

}
